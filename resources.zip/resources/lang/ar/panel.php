<?php

return [
    'site_title' => 'theqa',

];
